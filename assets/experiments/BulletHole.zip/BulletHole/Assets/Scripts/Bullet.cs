﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed;
    public GameObject perso;

    private Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        perso= GameObject.Find("perso");
    }

    // Update is called once per frame
    void Update()
    {
        rb.MovePosition(transform.position + transform.forward * Time.deltaTime * speed);
    }

    void OnTriggerEnter(Collider other)
    {
        GameObject stain;
        if (other.tag == "Ennemi")
        {
            stain = (GameObject)Resources.Load<GameObject>("Prefab/Blood");
        }
        else
        {
            stain = (GameObject)Resources.Load<GameObject>("Prefab/BulletHole");
        }

        if (other.tag != "Player")
        {
            //raycast
            RaycastHit hit;
            var direction = transform.position - perso.transform.position;
            Destroy(gameObject);
            if(Physics.Raycast(perso.transform.position, direction, out hit, direction.magnitude))
            {
                var updatedNormal = hit.normal;
                var rotation = Quaternion.LookRotation(-updatedNormal, Vector3.down);
                var r = Quaternion.Euler(rotation.eulerAngles + new Vector3(90f, 0f, 0f));
                Instantiate(stain, hit.point - new Vector3(0f, 0f, 0.01f), r);
                RaycastHit hit2;
                int layerMask = 1 << 0;
                var ray = hit.point + new Vector3(0.01f, 0.01f, 0.01f);
                if (other.tag == "Ennemi" && Physics.Raycast(new Ray(ray,direction), out hit2, 10f,layerMask,QueryTriggerInteraction.UseGlobal))
                {
                    GameObject bulletHole = (GameObject)Resources.Load<GameObject>("Prefab/BulletHole");
                    rotation = Quaternion.LookRotation(hit2.normal);
                    var rot = Quaternion.Euler(rotation.eulerAngles + new Vector3(90f, 0f, 0f));
                    Instantiate(bulletHole, hit2.point - new Vector3(0f, 0f, 0.01f), rot);
                }
            }
        }
        
            
    }
}
