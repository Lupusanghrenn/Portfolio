﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyAfterSec : MonoBehaviour
{
    [Tooltip("Time before the gameobject fade")]
    public float timeBeforeFade;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(waitBeforeFade(timeBeforeFade));
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator waitBeforeFade(float time)
    {
        yield return new WaitForSeconds(time);
        Destroy(gameObject);
    }
}
