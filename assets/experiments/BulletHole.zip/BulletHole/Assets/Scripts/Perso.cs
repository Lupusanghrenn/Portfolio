﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;


public class Perso : MonoBehaviour,InputMaster.IPlayerActions
{
    Rigidbody rb;
    private InputMaster controls;
    private Vector2 m_look;
    Vector2 m_Rotation = new Vector2();
    private bool canShoot = true;

    [Header("Player data")]
    public int nbHp=100;
    public int maxBullet = 12;
    public int nbBullet;
    public float rotateSpeed;
    [Tooltip("time between 2 bullets")]
    public float fireRate;
    [Tooltip("time needed for reloading")]
    public float reloadTime;

    [Header("UI data")]
    public UnityEngine.UI.Text currentBulletUI;
    public UnityEngine.UI.Text maxBulletUI;
    public UnityEngine.UI.Text hp;
    public RectTransform hpBar;

    [Header("gameObject")]
    public float moveSpeed;
    public GameObject gun;
    public GameObject sphere;
    //[SerializeField] public InputMasterNamespace.InputMaster controls;

    // Start is called before the first frame update
    void Awake()
    {
        rb=GetComponent<Rigidbody>();
        controls = new InputMaster();     
        nbBullet = maxBullet;
        maxBulletUI.text = "/ " + maxBullet;
        m_look = new Vector2();
        Cursor.visible = false;

        //en vrai les balles devrait etre des raycast mais c etait un test

        //Enabling input system
        controls.Player.Enable();
        controls.Player.SetCallbacks(this);
    }

    // Update is called once per frame
    void Update()
    {
        Cursor.visible = false;
        Look(m_look);
    }

    public void OnShoot(InputAction.CallbackContext context)
    {
        if(context.phase == InputActionPhase.Performed && canShoot && nbBullet>0)//autre moyen de tester si phase==performed
        {
            Debug.Log("Shoot");
            var bullet = (GameObject)Resources.Load("Prefab/Bullet", typeof(GameObject));
            Instantiate(bullet,sphere.transform.position,sphere.transform.rotation);
            nbBullet--;
            currentBulletUI.text = nbBullet.ToString();
            canShoot = false;
            //TODO Animation de tir
            StartCoroutine("waitForFireRate");
            //Debug.Log(context.control.device.GetType().Equals(UnityEngine.InputSystem.Mouse.all[1]));
            //Debug.Log(controls.devices.GetType());
        }
        
    }

    public void OnReload(InputAction.CallbackContext context)
    {
        if(context.performed)
        {
            Debug.Log("Reload");
            canShoot = false;
            StopAllCoroutines();//stopCoroutine marche pas
            //StopCoroutine(waitForReload());
            StartCoroutine("waitForReload");
            //Todo animation de reload
        }
    }

    IEnumerator waitForFireRate()
    {
        yield return new WaitForSeconds(fireRate);
        canShoot = true;
    }

    IEnumerator waitForReload()
    {
        yield return new WaitForSeconds(reloadTime);
        nbBullet = maxBullet;
        currentBulletUI.text = nbBullet.ToString();
        canShoot = true;
    }

    public void OnMovement(InputAction.CallbackContext context)
    {
        //Debug.Log("Move");
        var direction = context.ReadValue<Vector2>();
        var scaledMS = moveSpeed * Time.deltaTime;
        rb.MovePosition(transform.position + transform.TransformDirection(direction.x, 0f, direction.y) * scaledMS);
        //transform.localPosition += transform.TransformDirection(direction.x, 0f, direction.y) * scaledMS;

    }

    public void OnLook(InputAction.CallbackContext context)
    {
        Debug.Log(context.ReadValue<Vector2>());
        
        //context.control.==controls.GamepadXboxScheme)
    }

    public void OnAction(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            rb.AddExplosionForce(100f, rb.transform.position, 500f);
            takeDmg(10);
        }
    }

    private void takeDmg(int nbDegat)
    {
        nbHp -= nbDegat;
        var tmp = hpBar.localScale;
        tmp.x = (float)nbHp/100f;
        Debug.Log(tmp);
        hpBar.localScale = tmp;
        hp.text = nbHp.ToString();
        if (nbHp <= 0)
        {
            SceneManager.LoadScene(0);
        }
    }

    public void OnMoveX(InputAction.CallbackContext context)
    {
        m_look.x = context.ReadValue<float>();
    }

    public void OnMoveY(InputAction.CallbackContext context)
    {
        m_look.y = context.ReadValue<float>();
    }

    public void OnMove(InputAction.CallbackContext context)
    {
        
    }


    private void Look(Vector2 rotate)
    {
        const float kClampAngleX = 20.0f;
        const float kClampAngleY = 80.0f;

        m_Rotation.y += rotate.x * rotateSpeed * Time.deltaTime;
        m_Rotation.x -= rotate.y * rotateSpeed * Time.deltaTime;

        //m_Rotation.x = Mathf.Clamp(m_Rotation.x, -kClampAngleX/2, kClampAngleX);
        //m_Rotation.y = Mathf.Clamp(m_Rotation.y, -kClampAngleY, kClampAngleY);

        var localRotation = Quaternion.Euler(0.0f, m_Rotation.y, 0.0f);
        rb.MoveRotation(localRotation);//perso

        //rotation en x pour le gun et la cam uniquement
        localRotation = Quaternion.Euler(m_Rotation.x, 0.0f, 0.0f);
        gameObject.GetComponentInChildren<Camera>().transform.localRotation = localRotation;
    }
}
