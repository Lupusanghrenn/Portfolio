    ////WIP

# Contributing

[Full source code](https://github.com/Unity-Technologies/InputSystem) for the input system is available on GitHub. This is also where most of our development happens.

>NOTE: This includes the full source code for the managed/C# part of the system. At this point, the native, platform-specific C++ backends are still closed-source and require a source code license.

## Creating PRs

## Reporting Bugs

## Feature Requests

## Discussion

To ask questions or discuss the new input system, we have a [dedicated section on Unity's forum](https://forum.unity.com/forums/new-input-system.103/).
