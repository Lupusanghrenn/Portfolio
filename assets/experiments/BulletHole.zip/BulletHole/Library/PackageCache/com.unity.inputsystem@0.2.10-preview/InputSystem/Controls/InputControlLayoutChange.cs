namespace UnityEngine.InputSystem
{
    public enum InputControlLayoutChange
    {
        Added,
        Removed,
        Replaced
    }
}
