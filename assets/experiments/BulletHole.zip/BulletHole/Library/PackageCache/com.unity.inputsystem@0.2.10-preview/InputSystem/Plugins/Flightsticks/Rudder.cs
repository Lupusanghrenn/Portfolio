namespace UnityEngine.InputSystem.Flightsticks
{
    public class Rudder
    {
    }
}
