namespace UnityEngine.InputSystem.SteeringWheels
{
    // A steering wheel with optional pedals.
    public class SteeringWheel : InputDevice
    {
    }
}
