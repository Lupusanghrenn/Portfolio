#if UNITY_WEBGL || UNITY_EDITOR

////TODO

namespace UnityEngine.InputSystem.Plugins.WebGL
{
    public class WebGLJoystick : Joystick
    {
    }
}
#endif // UNITY_WEBGL || UNITY_EDITOR
