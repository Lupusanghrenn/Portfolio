﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;

[CustomEditor(typeof(PropSpawner))]
public class PropSpawnerEditor : Editor
{
    private PropSpawner spawner;
    private VisualElement rootElements;
    private VisualTreeAsset visualTree;

    private List<Editor> objectPreviewEditors;

    // Start is called before the first frame update
    void OnEnable()
    {
        spawner = (PropSpawner)target;
        rootElements = new VisualElement();
        visualTree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/UIElements/PropSpawnerTemplate.uxml");

        StyleSheet styleSheet = AssetDatabase.LoadAssetAtPath<StyleSheet>("Assets/UIElements/PropSpawnerStyle.uss");
        rootElements.styleSheets.Add(styleSheet);
    }

    public override VisualElement CreateInspectorGUI()
    {
        rootElements.Clear();

        visualTree.CloneTree(rootElements);

        UQueryBuilder<VisualElement> builder = rootElements.Query(classes: new string[] { "prefab-button" });
        builder.ForEach(addButtonIcon);

        return rootElements;
    }

    public void addButtonIcon(VisualElement button)
    {
        IMGUIContainer icon = new IMGUIContainer(() =>
       {
           string path = "Assets/Prefab/" + button.name + ".prefab";

           GameObject asset = AssetDatabase.LoadAssetAtPath<GameObject>(path);
           Editor editor = GetPreviewEditor(asset);

           editor.OnPreviewGUI(GUILayoutUtility.GetRect(90, 90), null);
       });

        icon.focusable = false;

        button.hierarchy.ElementAt(0).Add(icon);

        //spawn prefab
        button.RegisterCallback<MouseDownEvent>(evnt =>
        {
            SpawnPrefab(button.name);
        },TrickleDown.TrickleDown);
    }

    private void SpawnPrefab(string prefabToSpawn)
    {
        string path = "Assets/Prefab/" + prefabToSpawn + ".prefab";

        GameObject gameObject = Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>(path));
        //gameObject.transform.SetParent(spawner.transform);
        gameObject.transform.localPosition = new Vector3(0, 0, 0);

    }

    public Editor GetPreviewEditor(GameObject asset)
    {
        if (objectPreviewEditors == null)
        {
            objectPreviewEditors = new List<Editor>();
        }

        //Check if there's already a preview
        foreach (Editor editor in objectPreviewEditors)
        {
            if ((GameObject)editor.target == asset)
            {
                return editor;
            }
        }

        Editor newEditor = Editor.CreateEditor(asset);
        objectPreviewEditors.Add(newEditor);
        return newEditor;

    }

}
