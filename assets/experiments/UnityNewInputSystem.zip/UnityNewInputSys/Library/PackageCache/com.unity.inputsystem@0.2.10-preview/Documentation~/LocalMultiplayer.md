    ////WIP

# Local Multiplayer

Having multiple concurrent local players requires a few special considerations

## Multiplayer Device Pairing

## Multiplayer Actions

## Multiplayer UIs
