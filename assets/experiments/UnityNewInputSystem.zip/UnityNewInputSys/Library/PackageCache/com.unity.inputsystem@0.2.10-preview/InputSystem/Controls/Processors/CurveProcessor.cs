using System;

namespace UnityEngine.InputSystem.Processors
{
    public class CurveProcessor : InputProcessor<float>
    {
        public override float Process(float value, InputControl<float> control)
        {
            throw new NotImplementedException();
        }
    }
}
