using UnityEngine.InputSystem.Utilities;

namespace UnityEngine.InputSystem.LowLevel
{
    public interface IInputDeviceCommandInfo
    {
        FourCC GetTypeStatic();
    }
}
