namespace UnityEngine.InputSystem.Plugins.Steam
{
    public enum SteamControllerType
    {
        Unknown,
        SteamController,
        Xbox360,
        XboxOne,
        GenericXInput,
        PS4
    }
}
