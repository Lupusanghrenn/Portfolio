A new new input system.

[Videos](https://www.youtube.com/playlist?list=PLXbAKDQVwztY0hyyeEy9gifk-ffkgoy_Y)

More info in the [wiki](https://github.com/Unity-Technologies/InputSystem/wiki).

[Preview builds of the Unity editor](http://beta.unity3d.com/download/4f520c3a3153/public_download.html) that work with the project.
